# -*- coding:utf-8 -*-
import pandas as pd
import pprint
from pathlib import Path
import os, sys
import warnings
import win32api
import win32con
from openpyxl import load_workbook

def all_none(tpl):
    return all(x is None for x in tpl)

def doexcel():
    # path1 = os.path.dirname(__file__)  # 当前文件所在的目录
    # os.path.abspath('.')
    path1 = os.path.dirname(os.path.realpath(sys.executable))
    src_file = path1 + "\SWTestDeviceAuditList.xlsx"

    df = pd.read_excel(src_file, sheet_name=0).iloc[:,
         :]  # ‘,’前面是行，后面是列，sheet_name指定sheet，可是是int第几个，可以是名称，header从第几行开始读取


    # 1. 使用 openpyxl 获取合并单元格范围
    # 读取 Excel 文件（假设文件名为 merged_data.xlsx）
    wb = load_workbook(src_file)
    ws = wb.active


    # 获取所有合并区域的坐标
    merged_ranges = [mcr for mcr in ws.merged_cells.ranges]
    # print(merged_ranges)

    #2. 标记合并单元格的 NaN 位置
    # 将合并区域转换为 DataFrame 的行列索引
    merged_indices = []
    for mcr in merged_ranges:
        flag_hebing_kong = 0
        # print(mcr, )
        for row in ws[mcr.coord]:
            # print(row)
            for cell in row:
                if flag_hebing_kong:
                    continue
                if cell.row == mcr.min_row and cell.column == mcr.min_col:
                    if cell.value == None:  # 排除是合并单元格，但是内容为空的合并单元格
                        flag_hebing_kong = 1
                    # print(cell.row,mcr.min_row,cell.column,mcr.min_col,cell.value)
                    continue  # 跳过合并区域第一个单元格
                merged_indices.append((cell.row - 2, cell.column - 1))  # 转换为 Pandas 的 (行,列) 索引

    # 创建标记矩阵：True 表示该位置是合并单元格产生的 NaN
    mask = pd.DataFrame(False, index=df.index, columns=df.columns)
    # mask = pd.DataFrame(False, index=df.index, columns=df.columns)
    for row_idx, col_idx in merged_indices:
        mask.iloc[row_idx, col_idx] = True

    #3. 仅填充合并区域的 NaN
    # 对标记为合并区域的 NaN 进行前向填充
    # df_filled = df.where(~mask, df.ffill())#常规情况
    # 定义填充值（可自定义）
    fill_value = "合并标识"  # 例如 "N/A" 或根据需求动态生成
    df_filled = df.mask(mask, fill_value)#合并单元格不只是相同的就合并
    # print("精准填充后的结果：")
    # print(df_filled)

    # 遍历行
    first_num = 1
    for row in ws.iter_rows(values_only=True):
        if all_none(row):
            first_num += 1
        else:
            break
    # print(first_num)
    header_row = first_num - 2
    df_filled.columns = df_filled.iloc[header_row]  # 设置列名，此时的表头是第一行空内容，unnamed 0， 1， 2......，设置后，将header_row这一行的内容作为新的表头
    df_filled = df_filled.drop(header_row).reset_index(drop=True)  # 删除列名行
    #多个空行时删除其他空行,
    df_filled = df_filled.iloc[header_row:] #获取从header_row行开始包括header_row行，的所有数据，此时的header_row这一行已经变更成真正表头下的第一行内容
    df_filled.to_excel('upload.xlsx', sheet_name="sheet1", index=False,
                     engine='xlsxwriter')
try:
    result = doexcel()
except Exception as e:
    with open('error.txt', 'w') as f:  # 设置文件对象
        print(e, file=f)
